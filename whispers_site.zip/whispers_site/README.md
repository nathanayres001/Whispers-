# Whispers 2.0 — Minimal Website

A zero-backend MVP: write one sentence about how you feel; see one supportive sentence back.
Entries are saved to **localStorage** in the user’s browser.

## Quick Start (no code)
1. Upload these files to **Netlify**, **Vercel**, or **GitHub Pages**.
2. Visit your site. Done.

## Optional: AI Replies
If you have a serverless endpoint that accepts `{ "prompt": "..." }` and returns `{ "reply": "..." }`:
- Go to **About & Settings** in the app.
- Toggle **Use AI replies**.
- Paste your endpoint URL and optional API key.
- The site will POST to your endpoint and display `reply`.

### Example serverless function (pseudo)
```js
export default async function handler(req, res) {
  const { prompt } = await req.json();
  // call your AI provider here and craft a short, gentle reply
  res.json({ reply: "You are allowed to take up space." });
}
```

## Privacy
- By default, everything stays **on-device**. No network calls except loading this page and the local message pool.
- If you enable AI, your prompt is sent to your configured endpoint.

## Files
- `index.html` — Single-page app with Write / History / Settings panels.
- `styles.css` — Clean, calming UI.
- `app.js` — LocalStorage logic + optional AI endpoint integration.
- `supportive_messages.json` — Curated local reply pool.
- `favicon.svg` — Simple icon.
- `README.md` — You are here.

© 2025 Whispers.
